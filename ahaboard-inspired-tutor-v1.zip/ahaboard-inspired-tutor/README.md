# Aha-inspired AI whiteboard tutor (starter)

A mobile-first independent learning project inspired by the general idea of an AI tutor that explains on a board. It is not affiliated with ahaboard.ai and does not copy its private code, branding, or proprietary assets.

## Included in v1
- Responsive tutor workspace and lesson board
- Text chat powered by the OpenAI Responses API
- Board items returned by the tutor (headings, explanations, equations)
- Browser speech recognition for English/Indian English or Hindi input
- AI-generated speech with two selectable voice presets
- Stop playback to interrupt the tutor
- English, Hindi, and automatic English/Hindi/Hinglish response mode
- No account, checkout, subscription, or paywall in this starter

## Important voice behavior
This first version uses push-to-talk browser speech recognition and generated audio playback. You can stop the audio at any time and ask a follow-up. It is not a fully duplex, always-listening realtime voice session. Browser speech recognition support varies by browser. The app clearly labels generated speech as AI-generated.

## Requirements
- Node.js 20 or newer
- An OpenAI API key configured by a parent/guardian if API billing is involved. API usage can cost money.
- A modern browser. Chrome on Android is a practical first test.

Do not paste API keys into the browser app, public chat, screenshots, or `client/` files.

## Run locally
1. Extract the ZIP.
2. In the project folder, install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `server/.env`.
4. Add the API key to `server/.env` with a parent/guardian's help. Keep the key private.
5. Start both apps:
   ```bash
   npm run dev
   ```
6. Open the Vite URL shown in the terminal (usually `http://localhost:5173`).

The API server runs on `http://localhost:8787`.

## If testing from a phone
The simplest route is to open this project in a browser-based development workspace that supports Node.js, terminal commands, and environment secrets. Upload the ZIP, install dependencies, set `OPENAI_API_KEY` as a server-side secret (not a Vite/client variable), then run the dev command. Do not publish the server with a real key in source code.

## Configuration
- `OPENAI_MODEL` in `server/.env` controls the text model. Default: `gpt-6.2-astra`.
- `PORT` controls the server port.
- `VITE_API_URL` can be set in a client `.env` if the client and server are deployed separately.

The starter uses the OpenAI Responses API for tutor text and the Speech API for generated audio. The current Speech API integration is suitable as a prototype; OpenAI's current documentation says these speech models are scheduled for shutdown on January 6, 2027 and recommends migrating new real-time voice experiences to the Realtime API. API model and voice availability can change; consult the official OpenAI API docs before production deployment.

## Next build steps
1. Add image/PDF uploads and vision-based question reading.
2. Upgrade push-to-talk into a true low-latency realtime voice session.
3. Render charts and simple SVG diagrams on the board.
4. Save lessons locally or to a database, with explicit privacy controls.
5. Add a proper deployment configuration and rate limits.
